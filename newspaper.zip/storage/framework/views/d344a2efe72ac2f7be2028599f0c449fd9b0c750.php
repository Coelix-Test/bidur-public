<div class="news-item news-item-gradient" style="background-image: url('/img/thumb-news-item-gradient.png');">
    <div class="gradient">
        <div class="text-wrap">
            <div class="title">6 JOBS THAT PROBABLY WON’T BE AROUND IN 10 YEARS</div>
            <div class="meta"><span class="author">by Helen Nova</span> | <span class="time">5 hours ago</span></div>
            <div class="excerpt">Whether you’re trying to figure out a career path tailored to your abilities, or just curious of the kinds of jobs that society is slowly fading out, Boss Girl has the rundown on the 6 jobs that probably...</div>
            <div class="stars-rating-wrapper">
                <div class="star"></div>
                <div class="star star-active"></div>
                <div class="star star-active"></div>
                <div class="star star-active"></div>
                <div class="star star-active"></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\OSPanel\domains\newspaper\resources\views/parts/news-item-gradient.blade.php ENDPATH**/ ?>