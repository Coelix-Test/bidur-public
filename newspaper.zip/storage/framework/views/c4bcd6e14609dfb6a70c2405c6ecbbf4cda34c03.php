<div class="recent-sidebar">
    <?php
    $controller = new \App\Http\Controllers\PostController();
    ?>
    <?php $__currentLoopData = $allPosts['all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $allInfoRecent[] = $controller->getInfoOnPostForMain($post['post']->id);
        $i = 0;
        $GLOBALS['iForRecent'] = $i;
        $GLOBALS['allInfoRecent'] = $allInfoRecent;
        global $iForRecent;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php for($iForRecent = 0; $iForRecent < count($allInfoRecent)-1; $iForRecent++): ?>
            <div class="news-block small-image-news">
                <div class="title-line">אופנה</div>
                <?php
                dd($allInfoRecent);
                for ($innerI = $iForRecent; $innerI < 5; $innerI++){
                    if ($innerI < count($allInfoRecent)-1){
                        ?><?php echo $__env->make('parts/news-item-small', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php
                    }
                    $iForRecent = $innerI;
                    var_dump($iForRecent);
                }

                ?>

            </div>

            <div class="banner" style="background-image: url('https://via.placeholder.com/375x600');"></div>

            <div class="news-block small-image-news">
                <div class="title-line">אופנה</div>
                <?php

                for ($innerI = $iForRecent; $innerI < 5; $innerI++){
                if ($innerI < count($allInfoRecent)-1){
                ?><?php echo $__env->make('parts/news-item-small', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php
                }
                $iForRecent = $innerI;
                }
                ?>
            </div>
    <?php endfor; ?>


</div>
<?php /**PATH D:\OSPanel\domains\newspaper\resources\views/parts/recent-sidebar.blade.php ENDPATH**/ ?>