<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Newspaper</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- Styles -->
<link href="/css/app.css" rel="stylesheet">
<?php /**PATH D:\OSPanel\domains\newspaper\resources\views/parts/head.blade.php ENDPATH**/ ?>