<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostVideo extends Model
{
    protected $table = 'postVideos';
    public function post(){
        return $this->belongsTo(Post::class);
    }
}
